var myArray = [
  {
    "id":'1',
    'Name':'Nupur',
    'Group':'G1',
    'Center' :'Sector 14',
    'Class' : '2',
    'Age':'12',
    'Mentor' : 'Shashank'
  },
  {
    'id':'2',
    'Name' :"Nupur",
    'Group':'G1',
    'Center' :'Sector 14',
    'Class' : '2',
    'Age':'12',
    'Mentor' : 'Shashank'
  },
  {
    'id':'3',
    'Name' :'Nupur',
    'Group':'G1',
    'Center' :'Sector 14',
    'Class' : '2',
    'Age':'12',
    'Mentor' : 'Shashank'
  },

  ];

$(document).ready(function() {
  $('#myTable').DataTable( {
    data: myArray,
    columns: [
        { data: 'id' },
        { data: 'Name' },
        { data: 'Group' },
        { data: 'Center' },
        { data: 'Class' },
        { data: 'Age' },
        { data: 'Mentor' }

    ]
  } );
} );